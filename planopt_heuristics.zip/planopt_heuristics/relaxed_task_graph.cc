#include "relaxed_task_graph.h"

#include <iostream>
#include <vector>

using namespace std;

namespace planopt_heuristics {
RelaxedTaskGraph::RelaxedTaskGraph(const TaskProxy &task_proxy)
    : relaxed_task(task_proxy),
      variable_node_ids(relaxed_task.propositions.size()) {
    /*
      TODO: add your code for exercise 2 (b) here. Afterwards
        - variable_node_ids[i] should contain the node id of the variable node for variable i
        - initial_node_id should contain the node id of the initial node
        - goal_node_id should contain the node id of the goal node
        - the graph should contain precondition and effect nodes for all operators
        - the graph should contain all necessary edges.
    */

   // gera o nodo or de cada variável
   for ( const auto &variable : relaxed_task.propositions){
       variable_node_ids[variable.id] = graph.add_node(NodeType::OR);
   }

   // gera o nodo and do estado inicial
   initial_node_id = graph.add_node(NodeType::AND);
    for(const auto & variable: relaxed_task.initial_state){
        // pra cada variável no estado inicial adiciona um arco dela para o estado inicial
        graph.add_edge(variable_node_ids[variable], initial_node_id);
    }

   // gera o nodo and do estado objetivo
   goal_node_id = graph.add_node(NodeType::AND);
    for(const auto &goal : relaxed_task.goal){ // variáveis no estado objetivo devem ter um do nodo objetivo até elas
        graph.add_edge(goal_node_id, variable_node_ids[goal]);
    }
    for(const auto & op : relaxed_task.operators){ // pra cada operador

	

        NodeID node_op = graph.add_node(NodeType::AND, op.cost); // é um node and
        for(const auto &pre : op.preconditions){ // com arco dele até suas pré-condições
            graph.add_edge(node_op, variable_node_ids[pre]);
        }
        for(const auto &eff : op.effects){ // e com arco dos efeitos até ele
            graph.add_edge(variable_node_ids[eff], node_op);
        }
    }

}

void RelaxedTaskGraph::change_initial_state(const GlobalState &global_state) {
    // Remove all initial edges that where introduced for relaxed_task.initial_state.
    for (PropositionID id : relaxed_task.initial_state) {
        graph.remove_edge(variable_node_ids[id], initial_node_id);
    }

    // Switch initial state of relaxed_task
    relaxed_task.initial_state = relaxed_task.translate_state(global_state);

    // Add all initial edges for relaxed_task.initial_state.
    for (PropositionID id : relaxed_task.initial_state) {
        graph.add_edge(variable_node_ids[id], initial_node_id);
    }
}

bool RelaxedTaskGraph::is_goal_relaxed_reachable() {
    // Compute the most conservative valuation of the graph and use it to
    // return true iff the goal is reachable in the relaxed task.
    graph.most_conservative_valuation();
    //cout << "VVVVALUE OF GOAL " << graph.get_node(goal_node_id).forced_true << "\n";
    return graph.get_node(goal_node_id).forced_true;
    // TODO: add your code for exercise 2 (b) here
}

int RelaxedTaskGraph::additive_cost_of_goal() {
    // Compute the weighted most conservative valuation of the graph and use it
    // to return the h^add value of the goal node.

   graph.weighted_most_conservative_valuation();
   return graph.get_node(goal_node_id).additive_cost;

    // TODO: add your code for exercise 2 (c) here.
}
void RelaxedTaskGraph::collect_direct_costs(const AndOrGraphNode nd){

	best_achievers.insert(nd.id);
	if( nd.type== NodeType::OR){
		//se o nodo tem pelo menos 1 sucessor adiciona o best achiever
		if( nd.successor_ids.empty() == false){
			collect_direct_costs(graph.get_node(nd.achiever));
		}
	}
	else if( nd.type== NodeType::AND){
		// adiciona todos os sucessores de AND
		for(const auto &succ: nd.successor_ids){
			collect_direct_costs(graph.get_node(succ));	
		}	
	}


}
int RelaxedTaskGraph::ff_cost_of_goal() {
    // TODO: add your code for exercise 2 (e) here.
	
   graph.weighted_most_conservative_valuation();
   best_achievers.clear();
  
   collect_direct_costs(graph.get_node(goal_node_id));
   
   int sum_direct_cost = 0;
   std::unordered_set<NodeID> :: iterator itr;
   for( itr = best_achievers.begin(); itr!= best_achievers.end();itr++){
	sum_direct_cost += graph.get_node(*itr).direct_cost;
	
   }
   

   return sum_direct_cost;
}

}
